﻿<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>測試 JavaScript 程式的 Web 伺服器</title>
</head>
<body>
<p>Web伺服器的網址是: <br/><br/> http://localhost:8080/[目錄]/[HTML檔名.html]</p>
</body>
</html>