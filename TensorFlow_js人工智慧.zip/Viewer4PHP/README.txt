Place you PHP files in the php_files folder.

Modify php.ini (if required to enable extensions)

 - Currently using MySQL 5.4 (compiled from source)
 - SQLite3

If you have existing MySQL database; copy it to the folder: php_mysql\mysql\data


Run the viewer_for_php.exe program. 

Please note: you must have Internet Explorer or 
Mozilla Activex Control (http://www.iol.ie/~locka/mozilla/mozilla.htm (free download only 4.5MB))
installed for Viewer for PHP to work.

Questions, queries, suggestions.....

-------------------------
Sukhpal Singh 26-10-2009
sonusinghsonu@gmail.com
-------------------------