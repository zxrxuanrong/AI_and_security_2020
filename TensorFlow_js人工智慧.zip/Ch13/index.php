<?php
   phpinfo();
?>